# ETAPA 5B — homologação de negócio Gestor → WSPCP TOTVS TESTE

Data: 01/09/2026  
Ambiente: `TOTVS TESTE / CSED4J_DEV`, empresa `01`, filial `010004 - FILIAL_IV - VERTICALIZACAO`  
Banco Gestor: `gestor_pecas_test` (127.0.0.1:15432)  
Endpoint: `https://gtsdo143182.protheus.cloudtotvs.com.br:1465/ws/WSPCP.apw`  
Produto respondente: `WSPCP 12.1.2510`, `SourceApplication=SIGAPCP`, `ContextName=PROTHEUS`

## 1. OP utilizada e "antes" no MATA650

`A9716901001` (C2_NUM `A97169` / item `01` / sequência `001`).

| Campo | Antes |
|---|---|
| Produto | `PNT002002003` — BRACO ARTICULACAO |
| Armazém | `01` |
| Quantidade | 10,00 |
| Qtd. Produzida (`C2_QUJE`) | **0,00** |
| Roteiro / Revisão | 35 / 002 |
| Tipo OP (`C2_TPOP`) | **F - Firme** |
| Situação | N - Normal |
| Legenda | **Verde = Em aberto** (⇒ `C2_DATRF` vazio, sem movimento SH6) |
| Emissão / Previsão / Entrega | 27/08/2026 / 27/08/2026 / 28/08/2026 |

Roteiro real da OP, já recebido do próprio TOTVS via `ProductionOrder`:
operação `10` — CORTE — recurso `PLASMA` — `ActivityID 108761`;
operação `20` — USINAGEM — recurso `CNC-01` — `ActivityID 160893`.

## 2. Legenda do MATA650 neste ambiente

Capturada em `Outras Ações → Legenda`:
amarelo = Prevista; **verde = Em aberto**; **laranja = Iniciada**; branco = Ociosa;
azul = Encerrada parcialmente; vermelho = Encerrada totalmente.

## 3. Envios executados e ACK real

Todos com HTTP 200 e `RECEIVEMESSAGERESULT/TOTVSMessage/ResponseMessage`.

| # | Cenário | OP / operação / recurso | Qtd | CloseOperation | Intervalo | Status | InternalId |
|---|---|---|---|---|---|---|---|
| 1 | A — início, quantidade zero | A9716901001 / 10 / PLASMA | 0 | false | 08:00:00 → 09:47:11 | **OK** | 783154 |
| 2 | B — parcial | A9716901001 / 10 / PLASMA | 2 | false | 10:05:23 → 10:58:37 | **OK** | 783155 |
| 3 | C — novo apontamento | A9716901001 / 10 / PLASMA | 3 | false | 11:12:07 → 11:49:53 | **OK** | 783156 |
| 4 | D — fechamento da operação 10 | A9716901001 / 10 / PLASMA | 5 | **true** | 12:03:41 → 12:44:19 | **OK** | 783157 |
| 5 | parcial na última operação | A9716901001 / 20 / CNC-01 | 4 | false | 12:52:11 → 13:04:37 | **OK** | 783158 |
| 6 | fechamento da operação 20 | A9716901001 / 20 / CNC-01 | 6 | **true** | 13:06:19 → 13:14:53 | **OK** | 783159 |
| 7 | E — refugo | A9717001001 / 10 / ROBO P | refugo 1, `WasteCode=RP` | false | 13:18:07 → 13:23:29 | **OK** | 783160 |
| 8 | StopReport | recurso ROBO P, `StopReasonCode=0010` | — | — | 13:25:11 → 13:27:49 | **OK** | 783161 |
| 9 | StopReport | recurso ROBO P, `StopReasonCode=0018` | — | — | 13:34:11 → 13:36:29 | **OK** | 783162 |

ACK de sucesso real, íntegro (envio 9):

```xml
<TOTVSMessage xsi:noNamespaceSchemaLocation="xmlschema/general/events/StopReport_1_000.xsd">
  <MessageInformation version="1">
    <UUID>1a01666e-b781-5658-a100-dd54b7eadff9</UUID><Type>Response</Type>
    <Transaction>STOPREPORT</Transaction><StandardVersion>1.0</StandardVersion>
    <SourceApplication>SIGAPCP</SourceApplication><CompanyId>01</CompanyId>
    <BranchId>010004</BranchId><Product name="WSPCP" version="12.1.2510"/>
    <GeneratedOn>2026-09-01T13:36:41</GeneratedOn><ContextName>PROTHEUS</ContextName>
  </MessageInformation>
  <ResponseMessage>
    <ReceivedMessage><SentBy>GESTOR_PECAS</SentBy>
      <UUID>1a01666e-b781-5658-a100-dd54b7eadff9</UUID></ReceivedMessage>
    <ProcessingInformation><ProcessedOn>2026-09-01T13:36:41</ProcessedOn>
      <Status>OK</Status></ProcessingInformation>
    <ReturnContent><ListOfInternalId><InternalId>
      <Name>STOPREPORTINTERNALID</Name><Origin/><Destination>783162</Destination>
    </InternalId></ListOfInternalId></ReturnContent>
  </ResponseMessage>
</TOTVSMessage>
```

## 4. Rejeições reais e o que provaram

1. **`SMO010: DB error (Insert) ... Cannot insert duplicate key ... (010004, 9ETFHR, 3, 0)`**  
   Ocorreu com `ReportDateTime` em hora cheia (`09:00:00`). O reenvio idêntico gerou
   `9ETFHS`, provando que o `MO_IDAPON` é um contador do Protheus derivado do
   instante do apontamento, não do conteúdo do XML. Com `09:47:11` o mesmo evento
   foi aceito. **É condição do ambiente TOTVS, não do Gestor.**
2. **`AJUDA:A680OPTOT Capacidade da Operação desta OP já está totalizada — H6_OPERAC 20 inválido`**  
   Depois do envio 6. Prova que o `CloseOperation=true` do Gestor **realmente
   encerrou a operação** (`SH6.H6_PT`).
3. **`AJUDA:A250GANHPR A quantidade informada é maior que a quantidade registrada
   para esta Ordem de Produção`** em `A9717001001` (planejado 1, já apontado 1).
   Regra funcional do Protheus respeitada.
4. **`AJUDA:A680OPTOT ... H6_OP := A9717101001 -- Inválido`** — confirma que
   `A9717101001` já está totalizada, como informado pela Manufatura.

## 5. Efeito medido no Protheus

### PCPA112 — Log de Importação (filtro filial 010004, 01/09/2026)

| Transação | Status | OP | Oper. | Recurso | Qtd | Data Ini | Data Fim |
|---|---|---|---|---|---|---|---|
| Apontamento de Produção | Integrado com sucesso | A9717001001 | 10 | ROBO P | 1 | 13:18:07 | 13:23:29 |
| Apontamento de Produção | Integrado com sucesso | A9716901001 | 20 | CNC-01 | 6 | 13:06:19 | 13:14:53 |
| Apontamento de Produção | Integrado com sucesso | A9716901001 | 20 | CNC-01 | 4 | 12:52:11 | 13:04:37 |
| Apontamento de Produção | Integrado com sucesso | A9716901001 | 10 | PLASMA | 5 | 12:03:41 | 12:44:19 |
| Apontamento de Produção | Integrado com sucesso | A9716901001 | 10 | PLASMA | 3 | 11:12:07 | 11:49:53 |
| Apontamento de Produção | Integrado com sucesso | A9716901001 | 10 | PLASMA | 2 | 10:05:23 | 10:58:37 |
| Apontamento de Produção | Integrado com sucesso | A9716901001 | 10 | PLASMA | 0 | 08:00:00 | 09:47:11 |
| **Apontamento de Parada** | **Integrado com sucesso** | — | — | ROBO P | 0 | 13:25 | 13:27 |

`Detalhes da Transação` das linhas aceitas: `OK`.

### MATA650 — antes/depois

| Momento | Legenda | `C2_QUJE` |
|---|---|---|
| Antes de qualquer envio | **Verde — Em aberto** | 0,00 |
| Depois do envio 1 (quantidade zero) | **Laranja — Iniciada** | 0,00 |
| Depois dos envios 2 a 6 (10 peças, duas operações fechadas) | Laranja — Iniciada | 0,00 |

[CONFIRMADO] O primeiro movimento SH6 é o que muda "Em aberto" → "Iniciada",
mesmo com quantidade zero.

[CONFIRMADO] Nesta parametrização o `ProductionAppointment` via WSPCP alimenta o
reporte de operação em SH6 (`ApprovedQuantity → H6_QTDPROD`,
`ScrapQuantity → H6_QTDPERD`, `CloseOperation → H6_PT`), **mas não preenche
`C2_QUJE` nem `C2_DATRF`**. Portanto a OP não passa a "Encerrada parcialmente"
nem "Encerrada totalmente" por esta rota.

[CORROBORAÇÃO INDEPENDENTE] A OP `PCMDPG01001` recebe apontamentos diários da
PC-Factory desde 19/08/2026, todos "Integrado com sucesso", e também está com
`Qtd.Produzid = 0,00` e legenda "Iniciada". O comportamento é do ambiente, não
do Gestor.

## 6. Códigos TOTVS TESTE confirmados

### SX5 grupo 44 — Motivo de Parada (`Cadastro de Motivo Parada`)

`0009` REFEICAO · `0010` MANUTENCAO PREVENTIVA · `0011` MANUTENCAO MECANICA
CORRETIVA · `0012` MANUTENCAO ELETRICA CORRETIVA · `0013` ATRASO FORNECEDOR ·
`0014` ANTECIPACAO DE PECA · `0015` PECA NAO CONFORME · `0016` PROBLEMA DE
ESTRUTURA · `0017` FURO DE ESTOQUE · `0018` AJUSTANDO SETUP · `0019` TROCA DISCO
LIXADEIRA · `0020` BANHEIRO · `0021` ERRO DE SEPARACAO · `0022` TROCA DE ARAME ·
`0023` TROCA DE BICO · `0024` TROCA DE BOCAL · `0025` TROCA DE CONDUITE ·
`0026` TROCA DE GAS · `0027` PROBLEMA NA TOCHA · `0028` PROBLEMA MAQUINA DE
SOLDA · `FE` FALTA DE ENERGIA ELETRICA.

Homologados no envio real: `0010` e `0018`.

### Motivo de Refugo — `WasteCode` (`Cadastro de Motivo Refugo`)

`FH` FALHA HUMANA · `FM` FALHA MECANICA · `FP` FALHA MATERIA PRIMA ·
`NC` NAO CONFORME · `RB` REBARBA · `RP` REJEITO DO PROCESSO.

Homologado no envio real: `RP`.

[CONFIRMADO] O `wasteCode=1` observado no arquivo do integrador PC-Factory
**não é código válido neste ambiente**. Os códigos reais são alfabéticos de dois
caracteres.

## 7. OP `02911901002` — avaliada a pedido e reprovada por condição funcional

| Campo | Valor lido no MATA650 |
|---|---|
| OP | `029119` / item `01` / sequência `002` |
| Filial | `010007 - FILIAL VII - CENTRAL DE PECAS` |
| Produto | `IPM015002007` — COMPLEMENTO CENTRAL FUNCO ESQ.-JD |
| Quantidade / Produzida | 1,00 / 0,00 |
| Tipo OP / Situação / Legenda | F - Firme / N - Normal / verde (Em aberto) |
| Roteiro / Armazém | 03 / 08 |

`Processo Produtivo (PCPA124)` na filial `010007` não possui nenhum registro para
`IPM015002007`: os produtos iniciados por "I" vão de `IPCX03007013` a
`IPCX03007067` e saltam para `KCG002000004`. Sem processo produtivo não existem
`ActivityCode` e `MachineCode` reais para reportar, e o Gestor não inventa
operação, recurso nem `ActivityID`. A OP fica **não apontável** até a Engenharia
cadastrar o roteiro dessa filial.

## 8. Achado de contrato — `ActivityID`

A matriz oficial PC-Factory ⇄ ERPs mostra `ActivityID` **sem coluna
TABELA/CAMPO PROTHEUS** (`--`); apenas `ActivityCode → SH6.H6_OPERAC` tem destino
no Protheus. O `ActivityID` continua sendo emitido quando o Gestor o recebeu do
`ProductionOrder`, mas não é o campo que identifica a operação no PCP.

## 9. Bug real corrigido no Gestor

O ACK de sucesso do WSPCP devolve `<InternalId><Name>…</Name><Origin/>
<Destination>783162</Destination></InternalId>`, com elementos filhos. O parser
tratava `Name` como atributo e concatenava todo o texto do nó, produzindo o
identificador corrompido `STOPREPORTINTERNALID783162` em vez do par
`("STOPREPORTINTERNALID", "783162")`. Corrigido em
`mes/integrations/totvs/outbound_ack.py`, preservando também o formato compacto.
Regressões adicionadas em `tests/test_totvs_outbound.py`.

## 10. Segurança do ambiente

Nenhuma senha foi exibida, registrada em código, teste ou documentação.
Nenhuma escrita direta em tabela TOTVS. Nenhum acesso ao TOTVS REAL
(`gtsdo142364:4010 / env producao`) nem ao banco `gestor_pecas` real.
