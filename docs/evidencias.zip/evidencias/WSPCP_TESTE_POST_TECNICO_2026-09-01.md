# WSPCP TESTE — POSTs técnicos de conectividade e autenticação

Data: 01/09/2026  
Alvo: `TOTVS TESTE / CSED4J_DEV`  
Endpoint: `https://gtsdo143182.protheus.cloudtotvs.com.br:1465/ws/WSPCP.apw`

## Primeiro POST — anônimo

- método: `POST`;
- `Content-Type`: `text/xml; charset=utf-8`;
- `SOAPAction`: `http://webservices.totvs.com.br/RECEIVEMESSAGE`;
- SOAP: 1.1;
- operação: `RECEIVEMESSAGE`;
- `CXML`: string vazia, deliberadamente sem `TOTVSMessage` de negócio, para
  não apontar OP durante a prova de transporte.

### Resposta observada

- HTTP: `500 Internal Server Error`;
- `Content-Type`: `text/xml; charset=utf-8`;
- `WWW-Authenticate`: ausente;
- corpo: envelope SOAP 1.1 válido;
- Fault code: `Receiver`;
- Fault string: `AUTHENTICATION: USER NOT AUTHORIZED`.

Trecho integral do corpo, sem credenciais ou dados de OP:

```xml
<?xml version="1.0" encoding="utf-8"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                   xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                   xmlns:f="http://www.w3.org/2001/12/soap-faults">
  <SOAP-ENV:Body>
    <SOAP-ENV:Fault>
      <faultcode>Receiver</faultcode>
      <faultstring>AUTHENTICATION: USER NOT AUTHORIZED</faultstring>
    </SOAP-ENV:Fault>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
```

### Conclusão limitada à evidência

[CONFIRMADO] DNS, TLS, porta 1465, path, POST, SOAP 1.1, namespace, operação e
`SOAPAction` alcançam o WSPCP publicado.

[CONFIRMADO] O listener exige autorização antes de processar `CXML`.

[CONFIRMADO NA PRIMEIRA RESPOSTA] Ela não publicou `WWW-Authenticate`, não
retornou 401/403 e o WSDL não contém policy de segurança. Isoladamente, essa
resposta não identificava o mecanismo.

## Segundo POST — credencial REST em HTTP Basic

Após o usuário configurar localmente a credencial REST do TESTE, foi executada
uma única tentativa com HTTP Basic. A senha foi lida diretamente do `.env`, não
foi exibida nem passada como argumento de linha de comando.

A requisição manteve exatamente o mesmo `CXML` vazio e sem mensagem de negócio.

Resposta:

- HTTP: `200 OK`;
- `Content-Type`: `text/xml; charset=utf-8`;
- `WWW-Authenticate`: ausente;
- corpo: envelope SOAP 1.1 válido, 1614 caracteres;
- resultado: `RECEIVEMESSAGERESULT` com `TOTVSMessage/ResponseMessage`;
- produto respondente: `WSPCP`, versão `12.1.2510`;
- `ProcessingInformation/Status`: `ERROR`;
- mensagem: código `1`,
  `Não foi possível interpretar o arquivo XML. Document is empty`.

O `ERROR` é o resultado esperado do conteúdo técnico vazio: ele ocorreu depois
da autenticação e prova que o método passou a interpretar `CXML`. Nenhuma OP,
operação, quantidade, recurso ou produto foi enviado.

## Conclusão atual

[CONFIRMADO] A publicação externa WSPCP do TOTVS TESTE aceita a credencial REST
configurada por HTTP Basic.

[CONFIRMADO] O transporte completo chegou a
`RECEIVEMESSAGERESULT/TOTVSMessage/ResponseMessage/ProcessingInformation`.

[CONFIRMADO] Nenhuma senha foi gravada em código, teste, documentação ou
evidência. Ela permanece somente no `.env` local.

[NÃO VERIFICADO] O ACK de uma mensagem de negócio e qualquer efeito em
PCPA112/SH6/MATA650 ainda dependem de uma OP explicitamente autorizada.
