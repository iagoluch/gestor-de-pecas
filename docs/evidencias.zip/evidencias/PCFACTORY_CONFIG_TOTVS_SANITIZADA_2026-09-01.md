# Configuração PC-Factory/MES → TOTVS — extrato sanitizado

Data da análise: 01/09/2026  
Origem fornecida pelo usuário: `C:\Users\iago.luchtenberg\Downloads\integtotvs.txt`  
SHA-256: `9ECE21B7B89193D85A6A1C0844A235E1D480308E556477A5FC92CCAA9FA7FDCC`

## Segurança

O arquivo original contém credenciais ERP e connection strings. Ele não foi
copiado para o repositório. Este documento não contém usuário, senha, host de
banco, nome de banco ou connection string.

## Fatos não secretos observados

- XML de configuração válido, .NET Framework 4.5;
- `erpName=PROTHEUS`;
- `pcFactoryVersion=4`;
- `ENABLEAUTH=TRUE`;
- endpoint outbound exatamente
  `https://gtsdo143182.protheus.cloudtotvs.com.br:1465/ws/WSPCP.apw`;
- login e senha ERP estão preenchidos no arquivo original;
- `SFC=False`, coerente com o caminho PCP estudado;
- `companyID` e `branchID` estão vazios nessa configuração;
- `wasteCode=1` aparece como default local do integrador;
- há referências antigas a `PcfIntegService` e a outro endpoint comentado.

## Comparação segura com o Gestor

- o login do `.env` atual coincide com o login do integrador MES;
- a senha não coincide;
- nenhum dos dois valores foi exibido durante a comparação;
- a senha do `.env` atual foi preservada porque ela já autenticou ao vivo no
  WSPCP TESTE com HTTP 200; o arquivo pode refletir credencial anterior, outra
  rotação ou outro uso.

## Limites da evidência

[CONFIRMADO] O arquivo corrobora que o integrador MES usa autenticação e o mesmo
endpoint WSPCP externo TESTE.

[CONFIRMADO POR TESTE AO VIVO, NÃO PELO ARQUIVO] A credencial atual funciona por
HTTP Basic. A configuração `WSPCPSOAP` do arquivo não declara segurança; a
seção Basic explícita está associada ao binding EAI antigo. Por isso a prova do
mecanismo continua sendo o POST real de 01/09/2026.

[NÃO AUTORIZADO COMO CÓDIGO TOTVS] `wasteCode=1` é apenas um default observado
no MES. Não prova existência/validade no Protheus TESTE atual e não será usado
em `ProductionAppointment` até confirmação objetiva no TOTVS.

[NÃO USAR] Os endpoints antigos/internos do arquivo não substituem a publicação
externa TESTE na porta 1465.
