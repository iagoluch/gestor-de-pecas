# ETAPA 5C — como o Protheus efetiva a produção da OP (`C2_QUJE` / `C2_DATRF`)

Data: 01/09/2026  
Ambiente: `TOTVS TESTE / CSED4J_DEV`, empresa `01`, filial `010004`  
Fontes analisadas: release Protheus `12.1.2510`, pacote `totvspcp` (446 fontes ADVPL/TLPP)

## 1. Resposta curta

O `ProductionAppointment` **já é** o mecanismo. Ele não estava efetivando a
produção porque a operação reportada **não era a última do roteiro**.

`MATA681` só gera o movimento de produção quando a operação apontada é a última
do roteiro (`A680UltOper()`) ou quando a mensagem é de encerramento de OP. Nesse
momento ele chama `A680GeraD3("PR0", ...)`, que cria o **SD3**, e em seguida
`A250Atu()`, que soma o SD3 em `C2_QUJE` e preenche `C2_DATRF`.

## 2. Cadeia de chamadas, seguida no código

```text
WSPCP.receiveMessage (WSPCP.prw)
  → WSPCPRUN → execInteg(cXml, cTransac)
      Case cTransac == "PRODUCTIONAPPOINTMENT"  → MATI681
      Case cTransac == "STOPREPORT"             → MATI682
      Case cTransac == "MOVEMENTSINTERNAL"      → MATI250 (E + OP) ou MATI240
  → MATI681 (mensagem unica/MATI681.prw)
      MSExecAuto({|x,y| mata681(x,y)}, aSH6, nOperation)
  → MATA681 / A681Inclui (mata681.prx:835)
      If If(!(lUltOper==Nil),lUltOper,A680UltOper()) .Or. lEncerraOP
          A680GeraD3("PR0", SH6->H6_IDENT, lEncerraOP)   // cria SD3
          A250Atu(...)                                   // atualiza SC2
      EndIf
  → MATA250 / A250Atu (mata250.prx:3825 e 3862)
      Replace C2_QUJE  With C2_QUJE + SD3->D3_QUANT
      If (lProdTot .And. ...) .Or. lEncerraOP
          Replace C2_DATRF With Iif(MV_DATENC=="1", dDataBase, dEmissao)
      EndIf
```

### `A680UltOper()` — o portão real (mata680.prx:2718)

```text
lMES := AllTrim(SH6->H6_OBSERVA) == "TOTVSMES"
If l681 .And. !lVldOper .And. !lMES     // lVldOper = (MV_VLDOPER == "S")
    lRet := A680AskUlt(lPergunta)        // em ExecAuto sem AUTASKULT retorna .F.
Else
    // percorre SG2/SHY do produto+roteiro a partir da operação apontada;
    // se existir operação posterior válida → lRet := .F.
EndIf
```

### `A650DefLeg()` — a legenda (mata650.prx)

```text
Case nLeg == 3  // Iniciada
    C2_TPOP == "F" .And. Empty(C2_DATRF) .And. (nRegSD3 > 0 .Or. nRegSH6 > 0)
Case nLeg == 5  // Encerrada parcialmente
    C2_TPOP == "F" .And. !Empty(C2_DATRF) .And. C2_QUJE <  C2_QUANT
Case nLeg == 6  // Encerrada totalmente
    C2_TPOP == "F" .And. !Empty(C2_DATRF) .And. C2_QUJE >= C2_QUANT
```

A legenda vermelha só é atingível com `C2_DATRF` preenchido — é prova indireta
suficiente do campo, que o MATA650 não exibe no folder principal.

## 3. Por que a Etapa 5B não efetivou

Roteiro **35** de `PNT002002003` (OP `A9716901001`), lido no PCPA124:

| Operação | Recurso | Descrição |
|---|---|---|
| 01 | PCP | IMPRESSAO OP |
| 10 | PLASMA | CORTE |
| 20 | CNC-01 | USINAGEM |
| 30 | INSPEC | INSPECAO |
| **99** | **ALMOX4** | **FINALIZADA** ← última |

Na Etapa 5B o Gestor apontou apenas as operações `10` e `20`. O
`ProductionOrder` recebido do TOTVS trazia as **5 atividades**, mas o inbound
projeta em `catalogo_operacoes_op` somente as duas manuais: `01 → PCP` é
automática, `30 → INSPEC` fica como apontável de manutenção e `99 → ALMOX4` é
tratada como marco terminal (registrado no ROADMAP desde a Etapa 1). Como `20`
não é a última, `A680UltOper()` retornou falso e o MATA681 gravou apenas SH6.

### Corroboração independente — PC-Factory

Roteiro **15** de `SPCX05001050P` (OP `PCMDPG01001`, apontada diariamente pela
PC-Factory): `01`, `10`, `20`, `30`, `40`, `50`, `60`, **`99` FINALIZADA**.
A PC-Factory reporta somente a operação `20` (PRE-MONTAGEM). Por isso essa OP
também está com `Qtd.Produzid = 0,00` e legenda "Iniciada" há semanas. É o mesmo
mecanismo, não uma diferença entre os dois MES.

## 4. Teste controlado executado no TOTVS TESTE

OP `A9716901001`, filial `010004`, produto `PNT002002003`, quantidade planejada 10.

| Momento | `C2_QUJE` | Legenda | `C2_DATRF` |
|---|---|---|---|
| **ANTES** (14:05) | **0,00** | **laranja — Iniciada** | vazio (exigido pela legenda 3) |
| **DEPOIS** (14:06) | **10,00** | **vermelha — Encerrada totalmente** | **preenchido** (exigido pela legenda 6) |

Mensagens enviadas pelo Gestor, ambas `Status=OK`:

| Operação | Recurso | Qtd | `CloseOperation` | Intervalo | InternalId |
|---|---|---|---|---|---|
| 30 | INSPEC | 10 | true | 13:41:13 → 13:47:29 | `PRODUCTIONAPPOINTMENTINTERNALID` / `783163` |
| **99** | **ALMOX4** | **10** | **true** | 13:50:07 → 13:56:41 | `PRODUCTIONAPPOINTMENTINTERNALID` / `783164` |

PCPA112 registra as duas como **"Integrado com sucesso"**, detalhe `OK`,
processadas às 14:06:06 e 14:06:30.

Nenhum `UPDATE` foi feito em `SC2`. A quantidade e a data foram calculadas pelo
próprio Protheus a partir do SD3 gerado pelo MATA681.

## 5. Parametrização deduzida do comportamento observado

A mensagem do Gestor identifica `Product name="GESTOR_PECAS"`, logo
`H6_OBSERVA = "GESTOR_PECAS"` e `lMES = .F.` em `A680UltOper()`. Como a produção
ocorreu mesmo assim, o ramo `A680AskUlt` não foi usado — o que só acontece com
`lVldOper` verdadeiro. Portanto **`MV_VLDOPER = "S"` neste ambiente**, e o
Protheus valida a última operação pelo roteiro independentemente do remetente.

Consequência prática: **o Gestor não precisa se passar por `PPI`/PC-Factory.**

## 6. Respostas objetivas

1. **Quem atualiza `SC2.C2_QUJE`?** `A250Atu`/`MATA250` (`mata250.prx:3825`),
   `Replace C2_QUJE With C2_QUJE + SD3->D3_QUANT`.
2. **Quem preenche `SC2.C2_DATRF`?** O mesmo bloco (`mata250.prx:3862-3867`),
   quando a produção é total, ou é a última operação com `H6_QTDPROD > 0`, ou há
   encerramento explícito. O valor vem de `MV_DATENC` (`dDataBase` ou `dEmissao`).
3. **Movimento/tabela da produção efetiva:** **SD3** (movimento interno de
   produção), criado com `D3_OP` da ordem.
4. **`ProductionAppointment` sozinho basta?** **SIM**, desde que a operação
   reportada seja a última do roteiro. Não é necessária outra mensagem.
5. **Outra mensagem MES necessária?** Não. Existe uma alternativa —
   `MovementsInternal` com `InputOrOutput="E"` e `ProductionOrderNumber`
   preenchido roteia para `MATI250 → MATA250` — mas ela exige o tipo de
   movimento cadastrado no PCPA109 (`SOE.OE_VAR1`) e não é preciso usá-la.
6. **Rotina adicional disparada pelo PC-Factory?** Não para produzir. O
   PC-Factory usa o mesmo `ProductionAppointment`; sua `MovementsInternal` é
   documentada como *Requisição de Componentes*.
7. **Parametrização que faz o MATA681 só gravar SH6?** Sim: a combinação
   "operação apontada não é a última do roteiro" (`A680UltOper()` falso) com
   `lEncerraOP` falso. `MV_VLDOPER` e `H6_OBSERVA` decidem *como* essa validação
   é feita.
8. **O encerramento depende de SD3?** Sim. Sem SD3 não há soma em `C2_QUJE` nem
   preenchimento de `C2_DATRF`.
9. **Rotina que gera o SD3:** `A680GeraD3("PR0", SH6->H6_IDENT, lEncerraOP)`,
   chamada de dentro do MATA681; no caminho alternativo, o próprio MATA250.
10. **Como o PC-Factory efetiva hoje:** pela mesma regra. Nas OPs em que ela
    aponta a última operação, o Protheus produz; nas OPs em que ela para na
    operação intermediária (como `PCMDPG01001`), não produz.
11. **Diferença entre os quatro conceitos:**

| Conceito | Efeito | Onde |
|---|---|---|
| Apontar operação | tempo e quantidade da operação | `SH6.H6_QTDPROD` / `H6_QTDPERD` |
| Produzir quantidade | entrada de produção da OP | **SD3** → `SC2.C2_QUJE` |
| Fechar operação | impede novo apontamento naquela operação (`A680OPTOT`) | `SH6.H6_PT = "T"` |
| Encerrar OP | data real de fim e legenda final | `SC2.C2_DATRF` |

## 7. Efeito no Gestor

Nenhum contrato novo foi implementado — o `ProductionAppointment` já existente
resolve. Duas correções mínimas foram necessárias:

- `ActivityID` passou a ser **opcional** no mapper. A matriz oficial PC-Factory
  traz `--` na coluna TABELA/CAMPO PROTHEUS e o `MATI681.prw` **nunca lê esse
  campo** — só `ActivityCode`. Sem o ID vindo do `ProductionOrder`, o Gestor
  omite o elemento em vez de inventar um identificador do ERP. Comprovado em
  envio real: as operações `30` e `99` foram aceitas sem `ActivityID`.
- O outbound precisa alcançar o **marco terminal do roteiro**. O dado já chega
  do TOTVS no `ProductionOrder` (5 atividades), mas o inbound projeta apenas as
  operações manuais. Para a homologação, as operações `30 INSPEC` e `99 ALMOX4`
  foram inseridas no catálogo com `ativo = FALSE`, ficando fora do planejamento
  do operador e disponíveis para o outbound. Definir com a Manufatura a forma
  definitiva: `INSPEC` e `ALMOX4` estão entre os recursos sem `tipo_setor`
  classificado, pendência já registrada no ROADMAP.

## 8. Segurança

Nenhum `UPDATE`/`DELETE` manual em tabela Protheus. Nenhuma escrita direta em
`SC2`, `SD3` ou `SH6`. Nenhum acesso ao TOTVS REAL (`gtsdo142364:4010 /
env producao`) nem ao banco `gestor_pecas` real. Nenhuma senha exibida ou
gravada.
