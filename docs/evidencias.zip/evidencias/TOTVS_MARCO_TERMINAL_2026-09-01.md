# ETAPA 5 — correção complementar: marco terminal TOTVS

Data: 01/09/2026  
Ambiente: `TOTVS TESTE / CSED4J_DEV`, empresa `01`, filial `010004`  
Banco: `gestor_pecas_test`, schema **18**

## 1. O que faltava

A Etapa 5C provou que o Protheus só efetiva a produção quando o
`ProductionAppointment` reporta a **última operação do roteiro**
(`A680UltOper()` → `A680GeraD3` → SD3 → `A250Atu` → `C2_QUJE`/`C2_DATRF`).

O `ProductionOrder` já traz esse marco terminal — a OP `A9716901001` recebe as 5
atividades, incluindo `99 / FINALIZADA / ALMOX4`, com `ActivityID 128285` — mas
o inbound projetava apenas as duas operações manuais. O marco terminal existia
como diagnóstico auditável e desaparecia do roteiro persistido, deixando o
outbound sem como fechar a OP.

## 2. Como ficou

O marco terminal passou a ser **preservado no mesmo `catalogo_operacoes_op`**,
sem segunda tabela de roteiro, e continua **invisível para o operador**.

Migration **18** (`TOTVS_TERMINAL_MILESTONE_STATEMENTS`):

- `marco_terminal BOOLEAN NOT NULL DEFAULT FALSE`;
- `tipo_setor` passa a aceitar `NULL` — o marco terminal não pertence a nenhum
  setor do Gestor e **nenhum posto ALMOX4 nem setor Logística foi criado**;
- `CHECK (ck_catalogo_operacao_marco_terminal)`: linha terminal só existe com
  `ativo = FALSE`; linha apontável exige `tipo_setor` preenchido;
- índice parcial por `(codigo_op, marco_terminal)`.

Como toda consulta da Tela do Operador já filtra `ativo IS TRUE`, o marco
terminal é invisível por construção — nenhuma query de fila precisou mudar. A
constraint recusa qualquer tentativa de reativá-lo, inclusive por SQL direto.

Projeção real, reprocessando o XML original armazenado na inbox:

```text
atividades no XML: 5
operacoes projetadas: 3
  operacao= 10 recurso=PLASMA   setor='Corte'      ordem=2 terminal=False activity_id=108761
  operacao= 20 recurso=CNC-01   setor='Usinagem'   ordem=3 terminal=False activity_id=160893
  operacao= 99 recurso=ALMOX4   setor=None         ordem=5 terminal=True  activity_id=128285
```

`activities_projected` na inbox continua contando apenas as operações
executáveis (2), preservando o significado original do diagnóstico.

## 3. Disparo automático, nunca prematuro

Leitura canônica nova, somente `SELECT`:
`buscar_marco_terminal_outbound_totvs(codigo_op)`. Ela combina o marco terminal
do roteiro com o estado real da execução:

- uma operação apontável está **concluída** quando o **último evento** da máquina
  de estados do operador é `finalizado`;
- a execução da OP está concluída quando existe ao menos uma operação apontável
  e **todas** estão concluídas;
- nada é disparado na ingestão, por recebimento de roteiro, por operação
  intermediária ou por parcial ainda aberta.

O mapper `map_terminal_production_appointment` recusa a emissão enquanto houver
operação em aberto, listando quais são. Comprovado no banco real:

```text
  apontaveis/concluidas : 2 / 1
  em aberto             : ('20',)
  execucao concluida    : False
TERMINAL NAO EMITIDO: O marco terminal exige a execução da OP concluída no
Gestor; operações ainda em aberto: 20.
```

Após o operador concluir a operação 20 pelo fluxo canônico:

```text
  apontaveis/concluidas : 2 / 2
  em aberto             : ()
  execucao concluida    : True
```

## 4. Quantidade terminal

Função canônica única: `terminal_approved_quantity(milestone)`.

- A entrega da OP é o resultado da **última operação produtiva** do roteiro.
  Somar as operações intermediárias contaria a mesma peça uma vez por etapa.
- Só `boa` conta. `refugo` nunca vira peça boa; `retrabalho` bloqueia a emissão,
  igual ao apontamento comum, por não ter destino comprovado no MATA681/SH6.
- A quantidade vem de `eventos_quantidade_producao`, a fonte canônica, e **não**
  do planejamento.
- O saldo planejado nunca é usado para "completar" o encerramento. Se o Gestor
  concluiu menos que o planejado, segue a quantidade menor e o Protheus decide
  entre encerramento parcial e total.
- Quantidade boa maior que a planejada é **recusada com mensagem explícita**, em
  vez de truncada — o Protheus responderia `A250GANHPR` de qualquer forma.

Exemplo real: OP `A9716901001`, planejado 10, última operação `20` com
`boa = 10` e `refugo = 1` → `ApprovedQuantity = 10`, `ScrapQuantity = 0`.

## 5. Idempotência

A chave reutiliza o mesmo gerador determinístico do outbound
(`uuid5` sobre `gestor-pecas:<kind>:<referência>`), agora ancorada na OP e na
operação terminal:

```text
IDPCFactory = uuid5(NAMESPACE_URL,
    "gestor-pecas:productionappointment-terminal-key:A9716901001:99")
            = 5a493079-396f-55d9-9cba-40aba60b66ef
```

A mesma conclusão sempre produz a mesma chave e o mesmo `UUID`, mesmo que o
timestamp de conclusão mude no reprocessamento. A chave do terminal nunca
colide com a de um apontamento comum de operação.

## 6. Mensagem terminal gerada automaticamente

OP `A9716901001`, montada sem intervenção manual:

```xml
<MachineCode>ALMOX4</MachineCode>
<ProductionOrderNumber>A9716901001</ProductionOrderNumber>
<ActivityID>128285</ActivityID>
<ActivityCode>99</ActivityCode>
<ItemCode>PNT002002003</ItemCode>
<ReportQuantity>10</ReportQuantity>
<ApprovedQuantity>10</ApprovedQuantity>
<ScrapQuantity>0</ScrapQuantity>
<StartReportDateTime>2026-09-01T12:52:11</StartReportDateTime>
<EndReportDateTime>2026-09-01T14:38:53</EndReportDateTime>
<WarehouseCode>01</WarehouseCode>
<CloseOperation>true</CloseOperation>
```

`ActivityCode`, `MachineCode` e `ActivityID` são exatamente os recebidos do
TOTVS. `ActivityID` continua opcional: quando o Gestor não o tem, o elemento é
omitido, como já homologado na Etapa 5C.

## 7. Homologação real no TOTVS TESTE

### Envio 1 — OP `A9716901001`

Terminal automático transmitido ao WSPCP.

- ACK: HTTP 200, `Status=ERROR`,
  `AJUDA:A680OPTOT Capacidade da Operação desta OP já está totalizada`.
- Interpretação: essa OP foi encerrada totalmente na Etapa 5C, com o mesmo
  `ActivityCode 99 / MachineCode ALMOX4 / CloseOperation=true`. O Protheus
  recusa o **mesmo marco duas vezes** — idempotência no lado do ERP.
- Efeito: nenhum. A OP permaneceu `C2_QUJE = 10,00`, legenda vermelha.

### Envio 2 — OP `A9717001001`

| Momento | `C2_QUJE` | Legenda |
|---|---|---|
| ANTES (15:02) | 0,00 | laranja — Iniciada |
| DEPOIS (15:03) | 0,00 | laranja — Iniciada |

- Terminal automático: operação `99`, recurso `ALMOX4`, `ActivityID 159938`,
  `ApprovedQuantity = 1` (boa canônica) sobre planejado 1.
- ACK: HTTP 200, `Status=ERROR`,
  `Itens Sem Saldo Bloqueados | PPCX05001017 01 -14,00 Sem Saldo por Endereco |
  PPCX05001021 01 -1,00 | PPCX05001030 01 -1,00 | PPCX05001096 01 -2,00 ...`
- **Interpretação decisiva:** essa mensagem só é produzida quando o MATA681
  entra no caminho de **produção** e tenta baixar os empenhos da OP. Um
  apontamento que apenas grava SH6 nunca consome componentes. Ou seja, o marco
  terminal automático **alcançou exatamente `A680UltOper()` → `A680GeraD3` →
  `A250Atu`**, e parou numa condição de saldo do ambiente de TESTE, não no
  contrato nem no código do Gestor.
- Efeito: transação revertida integralmente; a OP não mudou.

### Envio 3 — OP `PCMHBW01001` — ciclo completo

OP escolhida no próprio TESTE: filial `010004`, produto `PNT002002003`
(BRACO ARTICULACAO), roteiro `35`, Tipo OP `F - Firme`, quantidade 8. Foi
selecionada porque dezenas de OPs do mesmo produto já constam **encerradas
totalmente** na base — prova de que a estrutura tem saldo de componente e fecha
até o fim, ao contrário da `A9717001001`.

A OP entrou no Gestor pelo **caminho real de integração**: PCPA109 →
Sincronização, com filtro `C2_NUM = "PCMHBW"` e apenas a entidade "Ordem de
produção" marcada. O Protheus enviou o `ProductionOrder` ao endpoint do Gestor e
a mensagem foi registrada em `gestor_pecas_test`:

```text
id 19 | ProductionOrder | 01|010004|PCMHBW01001 | processed | inserted
        activities_parsed = 5 | activities_projected = 2
```

Execução canônica no Gestor, pelo fluxo do operador:

| Operação | Recurso | Eventos | Boas |
|---|---|---|---|
| 10 | PLASMA | producao → parcial(5) → producao → finalizado(3) | 8 |
| 20 | CNC-01 | producao → parcial(6) → producao → finalizado(2) | 8 |

Concluídas as duas operações apontáveis, o marco terminal ficou disponível
sozinho e foi transmitido:

```text
MachineCode ALMOX4 | ActivityCode 99 | ActivityID 128285
ApprovedQuantity 8 | ScrapQuantity 0 | CloseOperation true
IDPCFactory 66338d0f-3060-5ccb-8247-f603f8a00779
ACK: HTTP 200, Status=OK, PRODUCTIONAPPOINTMENTINTERNALID = 783165
```

Efeito no MATA650:

| Momento | `C2_QUJE` | Legenda | `C2_DATRF` |
|---|---|---|---|
| ANTES | **0,00** | **laranja — Iniciada** | vazio |
| DEPOIS | **8,00** | **vermelha — Encerrada totalmente** | **preenchido** |

`C2_QUJE` igualou a quantidade planejada e a legenda 6 do `A650DefLeg` exige
`!Empty(C2_DATRF) .And. C2_QUJE >= C2_QUANT`. Nenhuma escrita direta em `SC2`.

[CICLO COMPLETO COMPROVADO]

```text
Protheus PCPA109/Sincronização
  → ProductionOrder → Gestor (gestor_pecas_test)
  → roteiro projetado com marco terminal 99/ALMOX4 inativo
  → operador conclui as operações 10 e 20
  → marco terminal automático (quantidade boa canônica = 8)
  → WSPCP → MATI681 → MATA681 → A680UltOper → A680GeraD3 → SD3
  → A250Atu → C2_QUJE 8 / C2_DATRF preenchido
  → legenda Encerrada totalmente
```

### Envio 4 — `PCMIXQ01001` — projeção automática na ingestão

O `ProductionOrder` da `PCMHBW01001` havia sido ingerido pelo backend que já
estava em execução, iniciado **antes** desta correção — por isso projetou só as
duas operações apontáveis, e o roteiro precisou ser reprojetado a partir da
mesma mensagem armazenada.

Após o reinício do serviço (15:39:35, posterior a todas as alterações de código,
feitas entre 14:32 e 14:47) o caminho foi validado de ponta a ponta sem nenhuma
reprojeção manual. O Quick Tunnel mudou de URL no reinício e o PCPA109 passou a
apontar para `https://diane-projectors-smooth-chargers.trycloudflare.com/PcfIntegService`,
com o diagnóstico de Comunicação verde.

Sincronização de uma segunda OP (`C2_NUM = "PCMIXQ"`, apenas a entidade
"Ordem de produção"):

```text
id 22 | ProductionOrder | 01|010004|PCMIXQ01001 | processed | inserted
        activities_parsed = 5 | activities_projected = 2

catalogo_operacoes_op, fonte totvs_production_order_v1:
  10 PLASMA  setor=Corte     ordem=2 ativo=true  marco_terminal=false  id=108761
  20 CNC-01  setor=Usinagem  ordem=3 ativo=true  marco_terminal=false  id=160893
  99 ALMOX4  setor=NULL      ordem=5 ativo=false marco_terminal=TRUE   id=128285
```

[CONFIRMADO] O marco terminal é projetado **direto na ingestão**, inativo e sem
setor, com os metadados reais do TOTVS. `activities_projected` continua contando
apenas as duas operações executáveis.

[CONFIRMADO] Receber o roteiro **não** finaliza nada:

```text
  apontaveis/concluidas : 2 / 0
  em aberto             : ('10', '20')
  execucao concluida    : False
TERMINAL NAO EMITIDO: O marco terminal exige a execução da OP concluída no
Gestor; operações ainda em aberto: 10, 20.
```

### Conclusão da homologação

O ciclo está fechado ponta a ponta na OP `PCMHBW01001`: planejamento vindo do
Protheus, execução no Gestor, marco terminal automático e efetivação da produção
no ERP, sem intervenção manual e sem posto de operador para o `ALMOX4`.

As duas primeiras tentativas continuam valendo como evidência de robustez: a
`A9716901001` foi recusada com `A680OPTOT` por já ter sido encerrada com o mesmo
marco (não duplicação no lado do ERP) e a `A9717001001` parou em `Itens Sem
Saldo Bloqueados`, condição de estoque do ambiente, provando que a mensagem
alcança o caminho de produção do MATA681.

## 8. Arquivos alterados

| Arquivo | Papel |
|---|---|
| `app/database/migrations.py`, `app/database/schema.py` | migration 18 e versão |
| `mes/integrations/totvs/models.py` | `MappedProductionOperation.marco_terminal`, `tipo_setor` opcional |
| `mes/integrations/totvs/mapper.py` | projeção do marco terminal com metadados reais |
| `app/database/totvs_repository.py` | persistência inativa do terminal e contagem de projetadas |
| `mes/integrations/totvs/outbound_models.py` | `CanonicalTerminalMilestone` |
| `app/database/totvs_outbound_repository.py` | `buscar_marco_terminal_outbound_totvs` (somente SELECT) |
| `mes/integrations/totvs/outbound_mapper.py` | `terminal_approved_quantity`, `map_terminal_production_appointment` |
| `mes/integrations/totvs/outbound_service.py` | `build_terminal_production_appointment` |
| `scripts/homologar_totvs_outbound.py` | opção `--terminal-op` |

Nada foi alterado na máquina de estados do operador, na Tela do Operador, no
`StopReport`, no `ProductionOrder` ou no `WhoIs`.

## 9. Segurança

Nenhuma escrita direta em tabela Protheus. Nenhum acesso ao TOTVS REAL nem ao
banco `gestor_pecas` real. O PCPA109 foi aberto por engano e fechado com
**Cancelar**, sem alteração. Removi da base de TESTE apenas uma linha de
quantidade que eu mesmo havia criado na Etapa 5B (`origem =
'homologacao_etapa5b'`) e que o **próprio Protheus recusou** — ela não existia
no ERP. O fato real do operador e o refugo aceito pelo TOTVS foram preservados.
