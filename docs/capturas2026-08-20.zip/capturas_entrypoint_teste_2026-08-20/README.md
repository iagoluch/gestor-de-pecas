# Catálogo de telas — entrypoint de teste

Gerado em: 20/08/2026 10:05
Total de capturas: 146

## Escopo e segurança

- Código de interface: o mesmo carregado por `gestordepeca_teste.py`.
- Runtime: `GESTOR_TEST_MODE=1` e Qlik desativado.
- Dados: fixtures em memória; nenhuma captura grava no PostgreSQL.
- Autenticação: cada fluxo começa no `LoginDialog` com o usuário setorial correspondente.
- Escopo: somente os sete operadores setoriais; admin, Ajuda e Configurações foram excluídos.
- Resolução dos PNGs: 1920 × 1061.

## Cores dos estados da OP

- OP carregada/aguardando: card de fila azul `#004AAD`; ainda não há card em Produção.
- Em processo: verde `#00BF63`.
- Parada: vermelho `#FF3131`.
- Setup: ciano `#0CC0DF` (não disponível para Pintura e Solda).
- Retrabalho: marrom `#7A2F00`.
- Finalizada: a OP sai do painel Produção; a superfície vazia permanece neutra `#F1F3F6`. O amarelo `#FFDE59` identifica a ação Finalizado.

As cores foram conferidas nos pixels dos PNGs de Dobra, Usinagem, Serra, Pintura e Solda contra o mapeamento da tela do operador.

## Categorias

- `00_acesso`: 1 captura(s)
- `01_operador_destaque`: 7 captura(s)
- `02_operador_dobra`: 5 captura(s)
- `03_operador_usinagem`: 7 captura(s)
- `04_operador_serra`: 5 captura(s)
- `05_operador_corte`: 4 captura(s)
- `06_operador_pintura`: 2 captura(s)
- `07_operador_solda`: 12 captura(s)
- `08_funcoes_clicaveis_operador_dobra`: 20 captura(s)
- `09_funcoes_clicaveis_operador_usinagem`: 19 captura(s)
- `10_funcoes_clicaveis_operador_serra`: 19 captura(s)
- `11_funcoes_clicaveis_operador_pintura`: 17 captura(s)
- `12_funcoes_clicaveis_operador_solda`: 17 captura(s)
- `13_funcoes_clicaveis_operador_corte`: 11 captura(s)

O arquivo `manifesto.csv` relaciona cada PNG ao clique/rota que o produz.
Botões de atualização que não criam estado visual distinto foram documentados pelo estado pós-clique, sem duplicar imagens idênticas desnecessariamente.
